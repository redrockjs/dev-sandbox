module.exports = {
    mode: 'production',
};
