import App from './components/app/app';
import './global.css';

const app = new App();
app.start();
